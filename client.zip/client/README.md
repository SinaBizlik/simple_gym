# Simple Gym Management Platform - Frontend

This is the MVP frontend for the Simple Gym Management Platform, built using React.js.

## Tech Stack
- React.js
- React Router DOM
- Axios
- CSS (Modules/Inline)

## How to Install
1. Open terminal in this folder:
   ```bash
   cd client