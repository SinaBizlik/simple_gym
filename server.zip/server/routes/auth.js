const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// KAYIT OL (Register)
router.post('/register', async (req, res) => {
    try {
        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        const newUser = new User({
            username: req.body.username,
            password: hashedPassword,
            role: req.body.role || 'user'
        });
        await newUser.save();
        res.status(201).json({ message: "Kullanıcı oluşturuldu" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GİRİŞ YAP (Login)
router.post('/login', async (req, res) => {
    try {
        const user = await User.findOne({ username: req.body.username });
        if (!user) return res.status(404).json({ error: "Kullanıcı bulunamadı" });

        const isMatch = await bcrypt.compare(req.body.password, user.password);
        if (!isMatch) return res.status(400).json({ error: "Şifre hatalı" });

        // Token oluştur (Gizli anahtar 'SECRET_KEY' normalde .env dosyasında olmalı)
        const token = jwt.sign({ id: user._id, role: user.role }, 'GIZLI_ANAHTAR_123', { expiresIn: '1h' });
        
        res.json({ token, role: user.role });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
router.get('/users', async (req, res) => {
    try {
        const users = await User.find().select('-password'); // Şifreleri getirme, güvenlik için
        res.json(users);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// KULLANICI SİL (Admin İçin)
router.delete('/users/:id', async (req, res) => {
    try {
        await User.findByIdAndDelete(req.params.id);
        res.json({ message: "Kullanıcı silindi" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;