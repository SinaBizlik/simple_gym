const express = require('express');
const router = express.Router();
const Course = require('../models/Course');

router.get('/', async (req, res) => {
    try {
        // Query Parametrelerini Al (Örn: ?sort=price&minPrice=100)
        let query = {};
        
        // FİLTRELEME (Filtering)
        if (req.query.minPrice) {
            query.price = { $gte: req.query.minPrice }; // Belirli fiyattan yüksek olanlar
        }

        let coursesQuery = Course.find(query).populate('trainer', 'name expertise');

        // SIRALAMA (Sorting)
        if (req.query.sort) {
            const sortField = req.query.sort; // 'price' veya '-price'
            coursesQuery = coursesQuery.sort(sortField);
        }

        const courses = await coursesQuery;
        res.status(200).json(courses);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Ders Ekleme (Test için)
router.post('/', async (req, res) => {
    try {
        const newCourse = await new Course(req.body).save();
        res.status(201).json(newCourse);
    } catch (err) {
        res.status(400).json(err);
    }
});

module.exports = router;